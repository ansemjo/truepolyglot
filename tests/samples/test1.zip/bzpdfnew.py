#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
Copyright (C) DST (Digital Software Team) - All Rights Reserved
Unauthorized copying of this file, via any medium is strictly prohibited
Proprietary and confidential
Written by Benoît S. Meunier <benoit@systemd.info>, June 2018
'''

import sys
import re
import os.path
import tempfile
from subprocess import call

if len(sys.argv) != 3:
    print("Error: Invalid arguments")
    exit(1)

if not os.path.isfile(sys.argv[1]) or not os.path.isfile(sys.argv[2]):
    print("Error: file not found")
    exit(1)

tmp_pdf_file = tempfile.mktemp()

try:
    r = call(["pdftocairo", "-pdf", sys.argv[1], tmp_pdf_file])
    if r != 0:
        raise Exception('pdftocairo return an error')
except Exception as error:
    print("Error: " + "failed to execute pdftocairo")
    exit(1)

f = open(tmp_pdf_file, "rb")

pdf_buffer = []

while True:
    # Do stuff with byte.
    byte = f.read(1)
    if not byte:
        break
    pdf_buffer.append(byte)

f.close()

if pdf_buffer[0:5] == [b'%', b'P', b'D', b'F', b'-']:
    pdf_header = pdf_buffer[5:8]
    print("PDF Header found: " + bytes.join(b'', pdf_header).decode("utf-8"))

re1 = re.compile(b'startxref\n([0-9]+)')
m = re1.search(bytes.join(b'', pdf_buffer))

xref_idx = int(m.group(1))
print("Xref offset = " + str(xref_idx) + " (" + str(hex(xref_idx)) + ")")

re3 = re.compile(b'xref\n([0-9]+) ([0-9]+)')
m = re3.search(bytes.join(b'', pdf_buffer[xref_idx:xref_idx + 32]))
if m is None:
    print("Error : Invalid Xref")
    exit(1)
xref_nb_obj = int(m.group(2))
xref_hdr_size = m.end()

xref_table = []
re4 = re.compile(b'([0-9]+) ([0-9]+) ([f|n])')
o = 0
for i in range(xref_nb_obj):
    m = re4.search(bytes.join(b'', pdf_buffer[xref_idx + xref_hdr_size + o:]))
    if m is not None:
        o = o + m.end()
        xref_table.append((m.group(1), m.group(2), m.group(3)))

re2 = re.compile(b'([0-9]+) ([0-9]+) obj\n')
re5 = re.compile(b'\nendobj\n')

object_section_index = []

highest_obj_nb = 0

i = 0
while i < len(pdf_buffer):
    step = 1
    m = re2.match(bytes.join(b'', pdf_buffer[i:i + 32]))
    n = re5.match(bytes.join(b'', pdf_buffer[i:i + 8]))
    if m is not None:
        object_section_index.append(i)
        if int(m.group(1)) > highest_obj_nb:
            highest_obj_nb = int(m.group(1))
        step = m.end()
    if n is not None:
        object_section_index.append(i + 7)
        step = n.end()
    i = i + step

re6 = re.compile(b'trailer\n')
m = re6.search(bytes.join(b'', pdf_buffer[xref_idx + xref_hdr_size:]))
trailer_start = xref_idx + xref_hdr_size + m.start()
print("Trailer start: " + str(trailer_start) + " (" + hex(trailer_start) + ")")

re6 = re.compile(b'>>\n')
m = re6.search(bytes.join(b'', pdf_buffer[trailer_start:]))
trailer_end = trailer_start + m.end()

re7 = re.compile(b'trailer\n')

tmp_pdf_file2 = tempfile.mktemp()

g = open(tmp_pdf_file2, "wb")
g.write(bytes.join(b'', pdf_buffer[0:object_section_index[0] - 1]))
g.write(b'\n')

print("Object list:")
for idx, s in enumerate(object_section_index):
    if idx % 2 == 1:
        continue
    print(hex(s) + ":" + hex(object_section_index[idx + 1]))
    print("Object dump start:")
    print("---")
    print(bytes.join(b'', pdf_buffer[s:s + 10]))
    print("---")
    print("Object dump end:")
    t = object_section_index[idx + 1]
    print(bytes.join(b'', pdf_buffer[t - 10:t]))
    print("---")
    g.write(bytes.join(b'', pdf_buffer[s:object_section_index[idx + 1]]))
    g.write(b'\n')


zobj_start = str(highest_obj_nb + 1) + """ 0 obj
<<
  /Length 10
>>
stream
"""

zip_inject = [b'A']*19

f = open(sys.argv[2], "rb")

zip_buf = []

while True:
    # Do stuff with byte.
    byte = f.read(1)
    if not byte:
        break
    zip_buf.append(byte)
f.close()

if zip_buf[0:4] != [b'P', b'K', b'\x03', b'\x04']:
    print("Error: invalid zip file")
    exit(1)

re8 = re.compile(b'\x06\x05KP')
m = re8.search(bytes.join(b'', zip_buf[::-1]))
if m is None:
    print("Error: unable to find end of central directory")
    exit(1)

zip_ecd = len(zip_buf) - m.end()
print("Zip end of central directory: " + hex(zip_ecd))

zip_nbk = int.from_bytes(
    bytes.join(b'', zip_buf[zip_ecd + 4:zip_ecd + 6]), byteorder='little')
print("Zip nb of disk: " + str(zip_nbk))

zip_dks = int.from_bytes(
    bytes.join(b'', zip_buf[zip_ecd + 6:zip_ecd + 8]), byteorder='little')
print("Zip disk start at: " + str(zip_dks))

zip_nbcdr = int.from_bytes(
    bytes.join(b'', zip_buf[zip_ecd + 8:zip_ecd + 10]), byteorder='little')
print("Zip nb of central directory record: " + str(zip_nbcdr))

zip_tnbcdr = int.from_bytes(
    bytes.join(b'', zip_buf[zip_ecd + 10:zip_ecd + 12]), byteorder='little')
print("Zip total nb of central directory record: " + str(zip_tnbcdr))

zip_szcdr = int.from_bytes(
    bytes.join(b'', zip_buf[zip_ecd + 12:zip_ecd + 16]), byteorder='little')
print("Zip size of central directory: " + str(zip_szcdr))

zip_hdcdr = int.from_bytes(
    bytes.join(b'', zip_buf[zip_ecd + 16:zip_ecd + 20]), byteorder='little')
print("Zip central directory file header: " + hex(zip_hdcdr))

zip_szcmt = int.from_bytes(
    bytes.join(b'', zip_buf[zip_ecd + 20:zip_ecd + 22]), byteorder='little')
print("Zip comment length: " + str(zip_szcmt))

if zip_buf[zip_hdcdr:zip_hdcdr + 4] != [b'P', b'K', b'\x01', b'\x02']:
    print("Error: unable to find central directory")
    exit(1)
else:
    print("Parsing central directory")

acfs = 0
acfs_i = 0
while zip_buf[acfs + zip_hdcdr:acfs + zip_hdcdr + 4] == [b'P', b'K', b'\x01', b'\x02']:
    print("- Zip central directory file header n°" + str(acfs_i))
    zip_fl = int.from_bytes(
        bytes.join(b'', zip_buf[acfs + zip_hdcdr + 28:acfs + zip_hdcdr + 30]),
        byteorder='little')
    print("Zip file name length: " + str(zip_fl))
    zip_el = int.from_bytes(
        bytes.join(b'', zip_buf[acfs + zip_hdcdr + 30:acfs + zip_hdcdr + 32]),
        byteorder='little')
    print("Zip file name length: " + str(zip_el))
    zip_lfh = int.from_bytes(
        bytes.join(b'', zip_buf[acfs + zip_hdcdr + 42:acfs + zip_hdcdr + 46]),
        byteorder='little')
    print("Zip local file header: " + hex(zip_lfh))

    acfs_i = acfs_i + 1
    acfs = acfs + 46 + zip_fl + zip_el
    print("Zip current header: " + hex(zip_hdcdr + acfs))

zip_lfh = int.from_bytes(
    bytes.join(b'', zip_buf[zip_hdcdr + 42:zip_hdcdr + 46]),
    byteorder='little')
print("Zip local file header: " + hex(zip_lfh))

alfs = 0
for i in range(zip_nbcdr):
    print("- Zip local file header n°" + str(i))
    zip_fl = int.from_bytes(
        bytes.join(b'', zip_buf[zip_lfh + 26 + alfs:zip_lfh + 28 + alfs]),
        byteorder='little')
    print("Zip file name length: " + str(zip_fl))
    zip_el = int.from_bytes(
        bytes.join(b'', zip_buf[zip_lfh + 28 + alfs:zip_lfh + 30 + alfs]),
        byteorder='little')
    print("Zip extra field length: " + str(zip_el))
    zip_cps = int.from_bytes(
        bytes.join(b'', zip_buf[zip_lfh + 18 + alfs:zip_lfh + 22 + alfs]),
        byteorder='little')
    print("Zip compressed data length: " + str(zip_cps))
    zip_lfs = 30 + zip_fl + zip_el + zip_cps
    print("Zip current local file total size: " + hex(zip_lfs))
    alfs = alfs + zip_lfs
    print("Zip current header: " + hex(alfs))


#### Change OFFSET ####

acfs2 = 0
acfs_i2 = 0
while zip_buf[acfs2 + zip_hdcdr:acfs2 + zip_hdcdr + 4] == [b'P', b'K', b'\x01', b'\x02']:
    print("- Zip central directory file header n°" + str(acfs_i2))
    zip_fl = int.from_bytes(
        bytes.join(b'', zip_buf[acfs2 + zip_hdcdr + 28:acfs2 + zip_hdcdr + 30]),
        byteorder='little')
    print("Zip file name length: " + str(zip_fl))
    zip_el = int.from_bytes(
        bytes.join(b'', zip_buf[acfs2 + zip_hdcdr + 30:acfs2 + zip_hdcdr + 32]),
        byteorder='little')
    print("Zip file name length: " + str(zip_el))
    zip_lfh = int.from_bytes(
        bytes.join(b'', zip_buf[acfs2 + zip_hdcdr + 42:acfs2 + zip_hdcdr + 46]),
        byteorder='little')
    zip_lfh = zip_lfh + len(zip_inject)
    a = zip_lfh.to_bytes(4, 'little')
    zip_buf[acfs2 + zip_hdcdr + 42:acfs2 + zip_hdcdr + 46] = [a[i:i + 1] for i in range(len(a))]

    zip_lfh = int.from_bytes(
        bytes.join(b'', zip_buf[acfs2 + zip_hdcdr + 42:acfs2 + zip_hdcdr + 46]),
        byteorder='little')

    print("New zip local file header: " + hex(zip_lfh))

    acfs_i2 = acfs_i2 + 1
    acfs2 = acfs2 + 46 + zip_fl + zip_el
    print("Zip current header: " + hex(zip_hdcdr + acfs2))


zip_hdcdr2 = zip_hdcdr + len(zip_inject)
a = zip_hdcdr2.to_bytes(4, 'little')
zip_buf[zip_ecd + 16:zip_ecd + 20] = [a[i:i + 1] for i in range(len(a))]

zip_hdcdr2 = int.from_bytes(
    bytes.join(b'', zip_buf[zip_ecd + 16:zip_ecd + 20]), byteorder='little')
print("New zip central directory file header: " + hex(zip_hdcdr2))


z = open("out.zip", "wb")
z.write(bytes.join(b'', zip_inject))
z.write(bytes.join(b'', zip_buf[0:alfs]))
z.write(bytes.join(b'', zip_buf[zip_hdcdr:zip_hdcdr + acfs]))
z.write(bytes.join(b'', zip_buf[zip_ecd:zip_ecd + 22]))

z.close()

exit(1)


zip_buffer = b'AAAAAAAAAAAA'

zobj_end = """
endstream
endobj
"""


g.write(zobj_start.encode("utf-8"))
g.write(bytes.join(b'', zip_buffer))
g.write(zobj_end.encode("utf-8"))

xref_idx = xref_idx + len(zobj_start) + len(zobj_end) + len(zip_buffer)

for i in xref_table:
    print(i)

g.write(b'xref\n')
g.write(str(0).encode("utf-8"))
g.write(b' ')
g.write(str(len(xref_table)).encode("utf-8"))
g.write(b'\n')

for i in xref_table:
    g.write(i[0])
    g.write(b' ')
    g.write(i[1])
    g.write(b' ')
    g.write(i[2])
    g.write(b' \n')

g.write(bytes.join(b'', pdf_buffer[trailer_start:trailer_end]))

g.write(b'startxref\n')
g.write(str(xref_idx).encode("utf-8"))
g.write(b'\n%%EOF\n')

g.close()

print("Create tmp file (pdf normalized): " + tmp_pdf_file)
print("Create tmp file (output): " + tmp_pdf_file2)
